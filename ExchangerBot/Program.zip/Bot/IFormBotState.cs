﻿namespace ExchangerBot.Bot;

internal interface IFormBotState : IBotState
{
}
