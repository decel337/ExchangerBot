﻿using ExchangerBot.Bot.Models;
using Telegram.Bot.Types.ReplyMarkups;
using Telegram.Bot.Types;
using Telegram.Bot;

namespace ExchangerBot.Bot.States.ExchangeStates.CryptoStates;

internal class SelectCurrencyState : IFormBotState
{
    public async Task Handle(ITelegramBotClient bot, Message message, StateManager stateManager)
    {
        long chatId = message.Chat.Id;
        int messageId = message.MessageId;

        Order order = stateManager.GetOrder(chatId);

        InlineKeyboardMarkup buttons = new InlineKeyboardMarkup(
        [
            [InlineKeyboardButton.WithCallbackData("⬅️ Назад", "back")]
        ]);

        foreach (string name in Enum.GetNames(typeof(Currency)))
            buttons.AddButton(InlineKeyboardButton.WithCallbackData(name, "select_currency"));

        await bot.EditMessageText(chatId, messageId, "Выберите валюту для получения наличных:", replyMarkup: buttons);
    }
}