﻿using ExchangerBot.Bot.Models;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.ReplyMarkups;

namespace ExchangerBot.Bot.States.ExchangeStates.CryptoStates;
internal class EnterAmountUsdtState : IFormBotState
{
    public async Task Handle(ITelegramBotClient bot, Message message, StateManager stateManager)
    {
        long chatId = message.Chat.Id;
        int messageId = message.MessageId;
        await bot.DeleteMessage(chatId, messageId);

        var buttons = new InlineKeyboardMarkup(
            [
                [InlineKeyboardButton.WithCallbackData("⬅️ Назад", "back")]
            ]);

        Order order = stateManager.GetOrder(chatId);

        if (!int.TryParse(message.Text, out int amount) || amount <= 0)
        {
            await bot.EditMessageText(chatId, messageId - 1, $"{order}\nОшибка: введите корректное число.", replyMarkup: buttons);
            return;
        }

        order.UsdtAmount = amount;

        stateManager.SetOrder(chatId, order);

        stateManager.SetState(chatId, new SelectCurrencyState());
    }
}
