﻿using Telegram.Bot;
using Telegram.Bot.Types;

namespace ExchangerBot.Bot.States.ExchangeStates;

internal class CashState : IBotState
{
    public Task Handle(ITelegramBotClient bot, Message message, StateManager stateManager)
    {
        throw new NotImplementedException();
    }
}
