﻿using ExchangerBot.Bot.Models;
using ExchangerBot.Bot.States;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;

namespace ExchangerBot.Bot;

internal class StateManager
{
    private readonly Dictionary<long, IBotState> _userStates = new();
    public void SetState(long chatId, IBotState state)
    {
        _userStates[chatId] = state;
    }

    public IBotState GetState(long chatId)
    {
        return _userStates.TryGetValue(chatId, out IBotState? value) ? value : new MainMenuState();
    }
}

internal class OrderManager
{
    private readonly Dictionary<long, Order> _userStates = new();
    public void SetState(long chatId, Order state)
    {
        _userStates[chatId] = state;
    }

    public Order GetState(long chatId)
    {
        return _userStates.TryGetValue(chatId, out Order? value) ? value : throw new ArgumentNullException($"Order not found in {chatId}");
    }
}
