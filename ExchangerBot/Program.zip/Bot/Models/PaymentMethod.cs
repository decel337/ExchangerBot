﻿namespace ExchangerBot.Bot.Models;

internal enum PaymentMethod
{
    Cash,
    BankCard,
    Unknown
}
