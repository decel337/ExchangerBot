﻿namespace ExchangerBot.Bot.Models;
internal enum Currency
{
    USD,
    EUR,
    IDR,
    Unknown
}
