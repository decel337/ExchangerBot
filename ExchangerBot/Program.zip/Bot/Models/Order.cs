﻿namespace ExchangerBot.Bot.Models;

internal class Order
{
    public static int UsdtAmount;
    public static Currency Currency;
    public static bool IsCashPayment;


}
